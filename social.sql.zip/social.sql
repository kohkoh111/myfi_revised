-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Mar 06, 2021 at 02:57 AM
-- Server version: 5.7.30
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `social`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_body` text NOT NULL,
  `posted_by` varchar(60) NOT NULL,
  `posted_to` varchar(60) NOT NULL,
  `date_added` datetime NOT NULL,
  `removed` varchar(3) NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_body`, `posted_by`, `posted_to`, `date_added`, `removed`, `post_id`) VALUES
(1, 'Hello', 'koki_takata', 'koki_takata', '2021-03-06 01:37:07', 'no', 11);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `body` text NOT NULL,
  `added_by` varchar(60) NOT NULL,
  `user_to` varchar(60) NOT NULL,
  `date_added` datetime NOT NULL,
  `user_closed` varchar(3) NOT NULL,
  `deleted` varchar(3) NOT NULL,
  `likes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `body`, `added_by`, `user_to`, `date_added`, `user_closed`, `deleted`, `likes`) VALUES
(1, 'hello\r\n', 'koki_takata', 'none', '2021-02-21 14:09:02', 'no', 'no', 0),
(2, 'hello\r\n', 'koki_takata', 'none', '2021-02-21 18:05:59', 'no', 'no', 0),
(3, 'hello\r\n', 'koki_takata', 'none', '2021-02-21 18:06:03', 'no', 'no', 0),
(4, 'koki', 'koki_takata', 'none', '2021-02-21 18:06:29', 'no', 'no', 0),
(5, 'how are you', 'koki_takata', 'none', '2021-02-21 18:06:35', 'no', 'no', 0),
(6, 'how are you', 'koki_takata', 'none', '2021-02-21 18:07:05', 'no', 'no', 0),
(7, 'how are you', 'koki_takata', 'none', '2021-02-21 18:07:29', 'no', 'no', 0),
(8, 'Hello world', 'test_user', 'none', '2021-02-22 07:20:24', 'no', 'no', 0),
(9, 'Hello\r\n', 'koki_takata', 'none', '2021-03-06 00:30:27', 'no', 'no', 0),
(10, 'Hello\r\n', 'koki_takata', 'none', '2021-03-06 00:33:20', 'no', 'no', 0),
(11, 'Hello\r\n', 'koki_takata', 'none', '2021-03-06 00:33:29', 'no', 'no', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `signup_date` datetime NOT NULL,
  `profile_pic` varchar(255) NOT NULL,
  `num_posts` int(11) NOT NULL,
  `num_likes` int(11) NOT NULL,
  `user_closed` varchar(3) NOT NULL,
  `friend_array` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `email`, `password`, `signup_date`, `profile_pic`, `num_posts`, `num_likes`, `user_closed`, `friend_array`) VALUES
(1, 'Koki', 'Takata', 'koki_takata', 'Koh724@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99', '2021-02-21 00:00:00', 'assets/images/profile_pics/defaults/head_emerald.png', 10, 0, 'no', ',test_user,'),
(4, 'Test', 'User', 'test_user', 'Test@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99', '2021-02-22 00:00:00', 'assets/images/profile_pics/defaults/head_emerald.png', 1, 0, 'no', ',koki_takata,'),
(5, 'Test', 'User1', 'test_user1', 'Test1@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99', '2021-02-22 00:00:00', 'assets/images/profile_pics/defaults/head_deep_blue.png', 0, 0, 'no', ',');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
